#!/bin/bash
cd /var/www/html
chown www-data:www-data rds.conf.php
chown www-data:www-data s3-conf.php
